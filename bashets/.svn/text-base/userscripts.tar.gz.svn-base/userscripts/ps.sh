ps axk -%cpu,-%mem o pid,comm,%cpu,%mem | head -n 6
